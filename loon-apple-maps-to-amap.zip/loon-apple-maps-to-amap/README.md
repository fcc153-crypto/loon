# AppleMaps2Amap for Loon

将网页中的 **苹果地图 / Google 地图** 链接，在 Loon 内通过 MITM + Rewrite 重定向到 **高德地图**（`iosamap://`），实现点地址直接拉起高德导航。

> ⚠️ **原理限制**：仅对经过 HTTPS 解密的 HTTP/HTTPS 请求生效（网页里的 `maps.apple.com` / `maps.google.com` 链接）。App 内部直接发起的 URL Scheme 跳转 Loon 无法拦截。

## 支持的重写

| 原始链接 | 重写为 |
|---|---|
| `maps.apple.com/?q=地名` | `iosamap://path?dname=地名`（路线规划） |
| `maps.apple.com/?address=地址` | `iosamap://viewMap?poiname=地址` |
| `maps.apple.com/?ll=lat,lon` | `iosamap://viewMap?lat=&lon=` |
| `maps.google.com/?q=地名` | `iosamap://path?dname=地名` |
| `google.com/maps/place/名称` | `iosamap://viewMap?poiname=名称` |
| 其他 maps 域名任意路径 | `iosamap://`（高德首页） |

## 安装方式（推荐：URL 直接添加）

1. 将此仓库托管到 GitHub（公开仓库）。
2. 开启 GitHub Pages，或直接用 raw 链接：
   ```
   https://raw.githubusercontent.com/<你的用户名>/loon-apple-maps-to-amap/main/AppleMaps2Amap.plugin/AppleMaps2Amap.conf
   ```
3. 在 Loon 中：**配置 → 插件 → 添加插件**，粘贴上方 URL 即可订阅。
4. Loon 会按 `[MITM]` 提示安装证书；前往 iOS **设置 → 通用 → 关于本机 → 证书信任设置** 启用 Loon 证书。

也可以下载 `plugin.json` 后用 Loon 的「从文件导入」添加（见下方）。

## 手动安装（文件导入）

Loon **配置 → 插件 → 添加插件 → 从文件导入**，选择 `plugin.json`。

## 使用测试

1. 在 Safari / 微信内打开任意含地图链接的网页，点击地址。
2. 正常情况下应直接拉起高德地图。
3. 若未生效，先在 Loon 开启 MITM 并信任证书；查看 Loon 日志确认 `maps.apple.com` 是否被解密。

## 高德 URI 参考

- 路线规划：`iosamap://path?sourceApplication=xx&dname=目的地&dev=0&t=0`
- 查看位置：`iosamap://viewMap?sourceApplication=xx&poiname=名称&lat=纬度&lon=经度&dev=0`

详见 [高德开放平台 - iOS URI 调用](https://lbs.amap.com/api/uri-api/ios-uri-explain/)。

## 文件结构

```
loon-apple-maps-to-amap/
├── AppleMaps2Amap.plugin/
│   ├── AppleMaps2Amap.conf   # Loon 规则主体（Rewrite + MITM）
│   └── plugin.json           # Loon 插件清单（文件导入用）
└── README.md
```

## License

MIT
